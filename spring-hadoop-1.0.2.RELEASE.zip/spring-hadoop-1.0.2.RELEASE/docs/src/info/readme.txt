SPRING for APACHE HADOOP
------------------------
http://www.springsource.org/spring-data/hadoop

1. INTRODUCTION

Spring for Apache Hadoop is a framework extension for writing Hadoop jobs that
benefit from the features of Spring, Spring Batch and Spring Integration.

2. RELEASE NOTES

This release comes with complete reference documentation. For further
details, consult the provided javadoc for specific packages and classes.

3. DISTRIBUTION JAR FILES

The Spring for Apache Hadoop jars files can be found in the 'dist' directory. 

4. GETTING STARTED

Please see the reference documentation.
Additionally the blog at http://blog.springsource.com as well
as sections of interest in the reference documentation.

ADDITIONAL RESOURCES
Spring for Apache Hadoop Homepage: http://www.springsource.org/spring-data/hadoop
Hadoop Homepage: http://hadoop.apache.org