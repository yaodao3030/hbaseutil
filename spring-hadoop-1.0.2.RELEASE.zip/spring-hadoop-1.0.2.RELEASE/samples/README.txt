The samples applications have been moved into their own repository so they can be developed independently of the Spring for Apache Hadoop release cycle.

They can be found on github: 

https://github.com/SpringSource/spring-hadoop-samples
