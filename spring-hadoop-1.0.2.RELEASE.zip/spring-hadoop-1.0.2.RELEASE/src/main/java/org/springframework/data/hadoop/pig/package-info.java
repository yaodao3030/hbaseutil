
/**
 *
 * Package providing integration with
 * <a href="http://pig.apache.org/">Apache Pig</a>.
 *  
 */
package org.springframework.data.hadoop.pig;

