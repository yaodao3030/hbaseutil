/**
 * Local Spring-specific {@link cascading.tap.Tap} for <a href="http://www.cascading.org/">Cascading</a> library.
 * <p/>
 * Note that these taps are meant for 'local' use only.
 */
package org.springframework.data.hadoop.cascading.tap.local;