/**
 *
 * Support classes for <a href="http://www.cascading.org//">Cascading</a>.
 *
 */
package org.springframework.data.hadoop.cascading;