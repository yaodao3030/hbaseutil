/**
 *
 * Support classes for configuring Hadoop.
 *
 */
package org.springframework.data.hadoop.configuration;