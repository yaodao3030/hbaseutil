
/**
 *
 * Support classes for scripting Hadoop.
 *
 */
package org.springframework.data.hadoop.scripting;

