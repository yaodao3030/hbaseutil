
/**
 *
 * Package providing integration with 
 * <a href="http://hbase.apache.org/">Apache HBase</a>.
 *  
 */
package org.springframework.data.hadoop.hbase;

