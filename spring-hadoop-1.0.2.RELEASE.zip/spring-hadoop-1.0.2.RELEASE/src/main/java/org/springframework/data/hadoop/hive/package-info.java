
/**
 *
 * Package providing integration with 
 * <a href="http://hive.apache.org/">Apache Hive</a>.
 *  
 */
package org.springframework.data.hadoop.hive;

