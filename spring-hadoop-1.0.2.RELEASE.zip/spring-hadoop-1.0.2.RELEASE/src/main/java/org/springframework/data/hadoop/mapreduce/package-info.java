
/**
 *
 * Support classes for Hadoop core Map Reduce functionality such
 * as job (whether vanilla Map-Reduce or streaming).
 *
 */
package org.springframework.data.hadoop.mapreduce;

