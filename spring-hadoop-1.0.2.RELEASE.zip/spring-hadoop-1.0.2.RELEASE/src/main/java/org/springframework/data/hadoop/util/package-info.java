
/**
 * Helper classes
 */
package org.springframework.data.hadoop.util;

