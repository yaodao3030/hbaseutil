/**
 *
 * Hadoop FileSystem supporting classes.
 *
 */
package org.springframework.data.hadoop.fs;