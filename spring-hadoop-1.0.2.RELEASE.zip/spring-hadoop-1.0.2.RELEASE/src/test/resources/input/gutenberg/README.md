We download books from Project Gutenberg into this directory 
